// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_paint_ini_read( void )
{

	n_win *w_t = &nwin_tool;
	n_win *w_l = &nwin_layr;
	n_win *w_m = &nwin_thmb;


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );


	int a = N_BMP_ALPHA_CHANNEL_VISIBLE;
	int r =   0;
	int g = 200;
	int b = 255;

	n_bool shade     = n_paint_layer_shade_onoff;
	n_bool layer_scr = n_paint_layer_scroll_onoff;

	pensize       = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "size",         7 );
	mix           = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "mix",         25 );
	edge          = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "edge",         5 );
	air           = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "air",          0 );
	cp.a          = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "a",            a );
	cp.r          = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "r",            r );
	cp.g          = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "g",            g );
	cp.b          = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "b",            b );
	w_t->posx     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "tool_x",      -1 );
	w_t->posy     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "tool_y",      -1 );
	w_l->posx     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "layer_x",     -1 );
	w_l->posy     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "layer_y",     -1 );
	shade         = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "layer_shade",  0 );
	layer_scr     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "layer_scroll", 0 );
	thumbnail     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "thumbnail",    0 );
	w_m->posx     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "thumbnail_x", -1 );
	w_m->posy     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "thumbnail_y", -1 );
	antishake     = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "antishake",    0 );
	n_bool wintab = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "wintab",       1 );
	n_bool thread = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "thread",       1 );
	n_bool fastmd = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "fast_mode",    1 );
	zoom          = N_PAINT_ZOOM_ZERO + 1;
	grid          = n_false;
	pixelgrid     = n_false;
	graycanvas    = n_false;

	n_paint_layer_shade_onoff  = shade;
	n_paint_layer_scroll_onoff = layer_scr;
	n_paint_fastmode           = fastmd;


	// [!] : backward compatibility

	if ( w_t->posx == -1 )
	{
		w_t->posx = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "toolx", -1 );
	}

	if ( w_t->posy == -1 )
	{
		w_t->posy = n_ini_value_int_literal( &ini, N_PAINT_APPNAME, "tooly", -1 );
	}


	n_paint_wintab_onoff = wintab;
	n_paint_thread_onoff = thread;


	n_ini_free( &ini );


	return;
}

// internal
void
n_paint_ini_write( void )
{

	s32 tool_x, tool_y;
	n_win_position_relative( NULL, hwnd_tool, &tool_x, &tool_y );

	s32 layer_x, layer_y;
	n_win_position_relative( NULL, hwnd_layr, &layer_x, &layer_y );

	s32 thumbnail_x, thumbnail_y;
	if ( thumbnail )
	{
		n_win_position_relative( NULL, hwnd_thmb, &thumbnail_x, &thumbnail_y );
	} else {
		thumbnail_x = nwin_thmb.posx;
		thumbnail_y = nwin_thmb.posy;
	}

#ifdef _MSC_VER

	//

#else  // #ifdef _MSC_VER

	// [!] : MinGW version only

	if ( n_win_dwm_is_on() )
	{
		tool_x -= 5;
		tool_y -= 5;

		layer_x -= 5;
		layer_y -= 5;
	}

#endif // #ifdef _MSC_VER


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );

	n_ini_section_add_literal( &ini, N_PAINT_APPNAME );


	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "size"         );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "mix"          );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "air"          );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "a"            );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "r"            );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "g"            );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "b"            );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "toolx"        );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "tooly"        );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "tool_x"       );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "tool_y"       );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "layer_x"      );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "layer_y"      );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "layer_shade"  );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "layer_scroll" );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "thumbnail"    );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "thumbnail_x"  );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "thumbnail_y"  );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "antishake"    );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "wintab"       );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "thread"       );
	n_ini_key_del_literal( &ini, N_PAINT_APPNAME, "fast_mode"    );

	n_bool shade  = n_paint_layer_shade_onoff;
	n_bool scroll = n_paint_layer_scroll_onoff;
	n_bool wintab = n_paint_wintab_onoff;
	n_bool thread = n_paint_thread_onoff;
	n_bool fastmd = n_paint_fastmode;

	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "size        ", pensize     );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "mix         ", mix         );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "edge        ", edge        );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "air         ", air         );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "a           ", cp.a        );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "r           ", cp.r        );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "g           ", cp.g        );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "b           ", cp.b        );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "tool_x      ", tool_x      );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "tool_y      ", tool_y      );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "layer_x     ", layer_x     );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "layer_y     ", layer_y     );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "layer_shade ", shade       );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "layer_scroll", scroll      );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "thumbnail   ", thumbnail   );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "thumbnail_x ", thumbnail_x );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "thumbnail_y ", thumbnail_y );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "antishake   ", antishake   );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "wintab      ", wintab      );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "thread      ", thread      );
	n_ini_key_add_int_literal( &ini, N_PAINT_APPNAME, "fast_mode   ", fastmd      );

	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	n_explorer_refresh( n_false );


	return;
}

