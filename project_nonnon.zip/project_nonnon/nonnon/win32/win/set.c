// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_SET
#define _H_NONNON_WIN32_WIN_SET




#include "./dwm.c"
#include "./rect.c"
#include "./style.c"


#include "../sysinfo/version.c"




#include <shellapi.h>




typedef struct {

	// [ In/Out : Overridable ]


	// Window Position

	s32 posx, posy;


	// Real Client Size : hidden area is included

	s32 rcsx, rcsy;


	// [ Out : Auto-calculated ]


	// Client Size : visible area only

	s32 csx, csy;


	// Window Size : caption and borders are included

	s32 wsx, wsy;


	// Scroll Position

	s32 scrollx, scrolly;


	// Window State
	//
	//	same as wParam of WM_SIZE
	//
	//	0 == SIZE_RESTORED
	//	1 == SIZE_MINIMIZED
	//	2 == SIZE_MAXIMIZED

	int state;

} n_win;




#define n_win_zero(  f    ) n_memory_zero( f,    sizeof( n_win ) )
#define n_win_alias( f, t ) n_memory_copy( f, t, sizeof( n_win ) )

int
n_win_percent2dpi( int percent )
{

	int ret = 96;

	if ( percent == 100 )
	{
		ret =  96;
	} else
	if ( percent == 125 )
	{
		ret = 120;
	} else
	if ( percent == 150 )
	{
		ret = 144;
	} else
	if ( percent == 175 )
	{
		ret = 168;
	} else
	if ( percent == 200 )
	{
		ret = 192;
	} else
	if ( percent == 225 )
	{
		ret = 216;
	} else
	if ( percent == 250 )
	{
		ret = 240;
	} else
	if ( percent == 300 )
	{
		ret = 288;
	}// else


	return ret;
}

void
n_win_taskbarpos( int *ret_p, RECT *ret_r )
{

	// [x] : don't use SHAppBarMessage() : buggy
	//
	//	WinNT : don't use ABM_QUERYPOS : abd.rc will be zero
	//	Win9x : abd.uEdge will be zero(ABE_LEFT) in some cases

	// [Needed] : handling as range


	int  p = -1;
	RECT r; 


#ifdef _MSC_VER

	APPBARDATA abd; ZeroMemory( &abd, sizeof( APPBARDATA ) );
	abd.cbSize = sizeof( APPBARDATA );
	abd.hWnd   = NULL;
	SHAppBarMessage( ABM_GETTASKBARPOS, &abd );

	p = abd.uEdge;
	r = abd.rc;

#else  // #ifdef _MSC_VER

	s32 fx,fy,fsx,fsy;

	fx = fy = 0;
	n_win_desktop_size( &fsx, &fsy );


	s32 tx,ty,tsx,tsy;

	HWND h = n_win_hwnd_find_literal( NULL, "Shell_TrayWnd" );
	GetWindowRect( h, &r );

	n_win_rect_expand_range( &r, &tx, &ty, &tsx, &tsy );


	if ( ( tx <= fx )&&( ty <= fy ) )
	{

		if ( tsx >= fsx ) { p = ABE_TOP;  }
		if ( tsy >= fsy ) { p = ABE_LEFT; }

	} else

	if ( ( tsx >= fsx )&&( tsy >= fsy ) )
	{

		if ( tx <= fx ) { p = ABE_BOTTOM; }
		if ( ty <= fy ) { p = ABE_RIGHT;  }

	}

#endif // #ifdef _MSC_VER


	if ( ret_p != NULL ) { (*ret_p) = p; }
	if ( ret_r != NULL ) { (*ret_r) = r; }


	return;
}

void
n_win_minsize_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, s32 csx, s32 csy )
{

	// [Mechanism] : for resizable window like WS_OVERLAPPEDWINDOW


	if ( msg != WM_GETMINMAXINFO ) { return; }


	MINMAXINFO *m = (void*) lparam;
	if ( m == NULL ) { return; }


	{

		RECT rect = { 0, 0, csx, csy };
		AdjustWindowRect( &rect, n_win_style_get( hwnd ), n_posix_false );

		m->ptMinTrackSize.x = rect.right  - rect.left;
		m->ptMinTrackSize.y = rect.bottom - rect.top;

	}


	return;
}

n_posix_bool
n_win_fake_win7_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, LRESULT *ret )
{

	// [Mechanism]
	//
	//	call in a window procedure/WndProc() like this
	//
	//	{
	//		LRESULT ret = 0;
	//		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
	//		{
	//			return ret;
	//		}
	//	}


	if ( n_sysinfo_realversion_7_or_later() ) { return n_posix_false; }

	if ( n_posix_false == ( WS_SIZEBOX & n_win_style_get( hwnd ) ) ) { return n_posix_false; }


	static RECT         rect  = { 0,0,0,0 };
	static n_posix_bool onoff = n_posix_false;
	static n_posix_bool drag  = n_posix_false;
	static s32          oy    = 0;


	switch( msg ) {


	case WM_NCLBUTTONDBLCLK :

		if (
			( HTTOP    == LOWORD( wparam ) )
			||
			( HTBOTTOM == LOWORD( wparam ) )
		)
		{
//n_win_hwndprintf_literal( hwnd, " HTTOP/HTBOTTOM " );

			if ( onoff )
			{

				onoff = n_posix_false;

				s32 x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );
				n_win_move_simple( hwnd, x,y,sx,sy, n_posix_true );

			} else {

				onoff = n_posix_true;

				GetWindowRect( hwnd, &rect );
				s32 x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );
				s32 borders = GetSystemMetrics( SM_CYSIZEFRAME ) * 2;

				 y = 0;
				sy = GetSystemMetrics( SM_CYMAXIMIZED ) - borders;

				n_win_move_simple( hwnd, x,y,sx,sy, n_posix_true );

			}

		} else
		if ( HTCAPTION == LOWORD( wparam ) )
		{
//n_win_hwndprintf_literal( hwnd, " HTCAPTION " );

			if ( onoff )
			{

				onoff = n_posix_false;

				s32 x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );
				n_win_move_simple( hwnd, x,y,sx,sy, n_posix_true );

				if ( ret != NULL ) { (*ret) = 0; }
				return n_posix_true;
			}

		}

	break;

	case WM_NCLBUTTONDOWN :

		if ( HTCAPTION == LOWORD( wparam ) )
		{
			n_win_cursor_position( NULL, &oy );
		}

	break;

	case WM_MOVING :
//n_win_hwndprintf_literal( hwnd, " %08x %08x ", GetKeyState( VK_LBUTTON ), GetAsyncKeyState( VK_LBUTTON ) );
//n_win_hwndprintf_literal( hwnd, " %d ", onoff );

		if ( onoff )
		{

			RECT *r = (RECT*) lparam;
			if ( r == NULL ) { break; }

			n_posix_bool drag_full_windows = n_posix_false;
			SystemParametersInfo( SPI_GETDRAGFULLWINDOWS, 0, (void*) &drag_full_windows, 0 );

			s32 caption  = GetSystemMetrics( SM_CYCAPTION );
			s32 limit_sy = caption * 4;
			s32 cursor_x = 0;
			s32 cursor_y = 0; n_win_cursor_position( &cursor_x, &cursor_y );
//n_win_hwndprintf_literal( hwnd, " %d / %d ", cursor_y, limit_sy );

			s32 x,y,sx,sy;

			n_posix_bool finalize = n_posix_false;

			if ( cursor_y > limit_sy )
			{
				onoff = n_posix_false;

				n_win_rect_expand_size(     r,   &x, NULL, NULL, NULL );
				n_win_rect_expand_size( &rect, NULL, NULL,  &sx,  &sy );

				// [Patch] : Win95 : borders will remain sometimes
				if ( drag_full_windows == n_posix_false )
				{
					x = x + GetSystemMetrics( SM_CXSIZEFRAME );
				}

				y = cursor_y - oy;

				finalize = n_posix_true;
			} else {
				n_win_rect_expand_size(     r,   &x,   &y,  &sx,  &sy );
				y = 0;
			}

			n_win_rect_set( r, x, y, sx, sy );


			// [Needed] : WinXP or earlier : when drag full window is off

			if ( finalize )
			{
				if ( drag_full_windows == n_posix_false ) { drag = n_posix_true; }
			}

		}

	break;

	case WM_MOVE :

		if ( drag )
		{

			drag  = n_posix_false;
			onoff = n_posix_false;

			s32 x,y,sx,sy; n_win_rect_expand_size( &rect, NULL, NULL, &sx, &sy );
			s32 cursor_y = 0; n_win_cursor_position( NULL, &cursor_y );
			x = LOWORD( lparam );
			y = cursor_y - oy;
			n_win_move_simple( hwnd, x,y,sx,sy, n_posix_true );


			// [Needed] : Win9x : when drag full window is off

			//UpdateWindow( hwnd );
			n_win_refresh( hwnd, n_posix_true );


			if ( ret != NULL ) { (*ret) = 0; }
			return n_posix_true;
		}

	break;


	} // switch


	return n_posix_false;
}

#define N_WIN_SET_DEFAULT     ( 0       )
#define N_WIN_SET_CENTERING   ( 1 <<  0 )
#define N_WIN_SET_INNERPOS    ( 1 <<  1 )
#define N_WIN_SET_CLIPPING    ( 1 <<  2 )
#define N_WIN_SET_SCROLLBAR   ( 1 <<  3 )
#define N_WIN_SET_NEEDPOS     ( 1 <<  4 )
#define N_WIN_SET_FORCEPOS    ( 1 <<  5 )
#define N_WIN_SET_CALCONLY    ( 1 <<  6 )
#define N_WIN_SET_VC_PATCH    ( 1 <<  7 )

void
n_win_set( HWND hwnd, n_win *w_ret, s32 rcsx, s32 rcsy, int mode )
{

	// [Mechanism]
	//
	//	"rcsx" "rcsy"
	//		-1 : auto-calculation
	//
	//	"mode" : N_WIN_SET_*
	//
	//		CENTERING  : centering
	//		INNERPOS   : clamp when out of screen
	//		CLIPPING   : clipping by desktop size
	//		SCROLLBAR  : calculate for scrollbars
	//		NEEDPOS    : override : posx, posy : before other options
	//		FORCEPOS   : override : posx, posy :  after other options
	//		CALCONLY   : calculation only
	//		RESTORE    : for resotre position, size and state, using n_win.state


	// [x] : Troubleshooter : ShowWindow() misbehaves at WM_CREATE
	//
	//	1 : SetWindowPos() always uses ShowWindow() internally
	//	2 : ShowWindow() will be suppressed until the first DefWindowProc() call
	//	3 : a first set SW_* will be used


	n_win w; n_win_zero( &w );


	// Status

	if ( IsIconic( hwnd ) )
	{
//n_win_text_set_literal( hwnd, "Minimized" );

		if ( w_ret != NULL ) { w_ret->state = SIZE_MINIMIZED; }

		return;

	} else
	if ( IsZoomed( hwnd ) )
	{
//n_win_text_set_literal( hwnd, "Maximized" );

		// [x] : not supported

	} else {

		w.state = SIZE_RESTORED;

	}


	// Calculation Pipeline

	const n_posix_bool  is_win10 = n_sysinfo_version_10_or_later();
	const n_posix_bool dwm_onoff = n_win_dwm_is_on();

#ifdef _MSC_VER

	const n_posix_bool is_win8 = n_sysinfo_version_8_or_later();
	const s32              dpi = n_win_dpi( hwnd );

#endif // #ifdef _MSC_VER


	// Style

	const DWORD   style =   n_win_style_get( hwnd );
	const DWORD exstyle = n_win_exstyle_get( hwnd );


	// Desktop

	s32 desktop_sx;
	s32 desktop_sy;

	if ( WS_OVERLAPPEDWINDOW == ( style & WS_OVERLAPPEDWINDOW ) )
	{
		n_win_desktop_size_no_patch( &desktop_sx, &desktop_sy );
	} else {
		n_win_desktop_size         ( &desktop_sx, &desktop_sy );
	}


	// Scroll

	const s32 scroll_sx = GetSystemMetrics( SM_CXVSCROLL );
	const s32 scroll_sy = GetSystemMetrics( SM_CYHSCROLL );


	n_posix_bool scrollx_onoff = n_posix_false;
	n_posix_bool scrolly_onoff = n_posix_false;


	// [!] : non-client sizes : FIXEDFRAME = (EDGE + BORDER)

	s32 bar_sy   = 0;
	s32 frame_sx = 0;
	s32 frame_sy = 0;
	s32 nc_sx    = 0;
	s32 nc_sy    = 0;


	// [!] : WS_CAPTION = WS_BORDER | WS_DLGFRAME;

	if ( WS_CAPTION == ( WS_CAPTION & style ) )
	{

		if ( WS_THICKFRAME & style )
		{
//n_win_text_set_literal( hwnd, "SIZEFRAME" );

			frame_sx = GetSystemMetrics( SM_CXSIZEFRAME );
			frame_sy = GetSystemMetrics( SM_CYSIZEFRAME );

		} else {
//n_win_text_set_literal( hwnd, "FIXEDFRAME" );

			frame_sx = GetSystemMetrics( SM_CXFIXEDFRAME );
			frame_sy = GetSystemMetrics( SM_CYFIXEDFRAME );

		}

		// [!] : WS_EX_TOOLWINDOW has priority

		if ( WS_EX_TOOLWINDOW & exstyle )
		{
			bar_sy = GetSystemMetrics( SM_CYSMCAPTION );
		} else {
			bar_sy = GetSystemMetrics( SM_CYCAPTION   );
		}

	} else
	if ( WS_THICKFRAME & style )
	{

		frame_sx = GetSystemMetrics( SM_CXSIZEFRAME );
		frame_sy = GetSystemMetrics( SM_CYSIZEFRAME );

	} else
	if (
		( WS_DLGFRAME   & style )
		||
		( WS_EX_DLGMODALFRAME & exstyle )
	)
	{

		frame_sx = GetSystemMetrics( SM_CXFIXEDFRAME );
		frame_sy = GetSystemMetrics( SM_CYFIXEDFRAME );

	} else
	if ( WS_BORDER & style )
	{

		frame_sx = GetSystemMetrics( SM_CXBORDER );
		frame_sy = GetSystemMetrics( SM_CYBORDER );

	}// else


	nc_sx =   ( frame_sx * 2 );
	nc_sy = ( ( frame_sy * 2 ) + bar_sy );


	s32 oy  = 0;
	s32 osy = 0;

	if ( dwm_onoff )
	{

		if ( WS_SIZEBOX & style )
		{
			oy = osy = GetSystemMetrics( SM_CYEDGE ) * 2;
		} else {
			oy = osy = frame_sy * 2;
		}

//n_win_hwndprintf_literal( hwnd, "Offset : %d %d", oy, osy );
	}


	// Taskbar

	int  taskbar_pos;
	RECT taskbar_rect;

	s32  desktop_fx = 0;
	s32  desktop_fy = 0;
	s32  desktop_tx = desktop_sx;
	s32  desktop_ty = desktop_sy;


	n_win_taskbarpos( &taskbar_pos, &taskbar_rect );

	if ( taskbar_pos == ABE_TOP )
	{
		desktop_fy = taskbar_rect.bottom;
	} else
	if ( taskbar_pos == ABE_BOTTOM )
	{
		desktop_ty = taskbar_rect.top;
	} else
	if ( taskbar_pos == ABE_LEFT )
	{
		desktop_fx = taskbar_rect.right;
	} else
	if ( taskbar_pos == ABE_RIGHT )
	{
		desktop_tx = taskbar_rect.left;
	}

	if ( is_win10 )
	{
		if ( WS_OVERLAPPEDWINDOW == ( style & WS_OVERLAPPEDWINDOW ) )
		{
			if ( taskbar_pos == ABE_LEFT )
			{
				desktop_fx -= 7;
			} else {
				desktop_tx += 7;
			}
		}
	}


	// Current Position and Size

	w.csx = w.csy = 0;
	w.wsx = w.wsy = 0;

	{

		RECT r; GetWindowRect( hwnd, &r );

		n_win_rect_expand_size( &r, &w.posx, &w.posy, NULL, NULL );

	}

	{

		RECT r; GetClientRect( hwnd, &r );

		n_win_rect_expand_size( &r, NULL, NULL, &w.rcsx, &w.rcsy );

	}


	// Override

	if ( w_ret != NULL )
	{

		w.scrollx = w_ret->scrollx;
		w.scrolly = w_ret->scrolly;


		if ( mode & N_WIN_SET_NEEDPOS )
		{
//n_win_text_set_literal( hwnd, "Normal : Override : Position" );

			w.posx = w_ret->posx;
			w.posy = w_ret->posy;
		}

	}
	if ( rcsx >= 0 ) { w.rcsx = rcsx; }
	if ( rcsy >= 0 ) { w.rcsy = rcsy; }


	// Default Size

	// [!] : trick : ( w.rcsy + bar_sy ) < ( w.rcsy + nc_sy )

	w.csx = w.rcsx;
	w.csy = w.rcsy;
	w.wsx = w.rcsx;
	w.wsy = w.rcsy;

	if ( mode & N_WIN_SET_CLIPPING )
	{

		if ( desktop_sx > w.rcsx )
		{ 

			scrollx_onoff = n_posix_false;
			w.scrollx     = 0;

		} else {

			scrollx_onoff = n_posix_true;


			// [!] : trick : minus value means "out of display"

			w.posx = desktop_fx - frame_sx;
			w.csx  = desktop_sx;

#ifdef _MSC_VER

			if ( ( dwm_onoff )&&( is_win8 ) )
			{

				if ( dpi == n_win_percent2dpi( 100 ) )
				{
					w.posx -= frame_sx * 2;
				} else {
					w.posx -= frame_sx * ( 2 + ( dpi / 96 ) );
				}

			}

#endif // #ifdef _MSC_VER

		}


		s32 tmp_rcsy;


		if ( dwm_onoff )
		{
			tmp_rcsy = ( w.rcsy +  nc_sy + oy );
		} else {
			tmp_rcsy = ( w.rcsy + bar_sy + oy );
		}


		if ( desktop_sy > tmp_rcsy )
		{
//n_win_text_set_literal( hwnd, "Scroll Y : Window" );

			scrolly_onoff = n_posix_false;
			w.scrolly     = 0;


			// [!] : trick : ( w.rcsy + bar_sy ) < ( w.rcsy + nc_sy )
 
			w.csy = w.rcsy;

		} else {

			w.posy = desktop_fy - frame_sy;
			w.csy  = desktop_sy -   bar_sy;


			if ( dwm_onoff )
			{
				w.posy += oy;
				w.csy  -= osy;
			}


			if ( w.rcsy > w.csy )
			{
//n_win_text_set_literal( hwnd, "Scroll Y : ON" );
				scrolly_onoff = n_posix_true;
			} else {
//n_win_text_set_literal( hwnd, "Scroll Y : OFF" );
				scrolly_onoff = n_posix_false;
			}

#ifdef _MSC_VER

			if ( scrolly_onoff )
			{
				if ( ( dwm_onoff )&&( is_win8 ) )
				{
					w.posy -= GetSystemMetrics( SM_CYSIZEFRAME );
					if ( dpi != 96 ) { w.csy -= GetSystemMetrics( SM_CYSIZEFRAME ) - 1; }
				}
			}

#else  // #ifdef _MSC_VER

			// [!] : MinGW version only

			if ( ( dwm_onoff )&&( is_win10 ) )
			{
				w.posy -= frame_sy;
				w.csy  += frame_sy;
			}

#endif // #ifdef _MSC_VER

		}

	}


	// [ Mechanism ]
	//
	//	one more time! : a little bit complicated!
	//
	//	if SB_HORZ(left-right bar) => reduce bar size from client area y
	//	if window size gets more than desktop size by scrollbar size, also re-calculate

	if ( mode & N_WIN_SET_SCROLLBAR )
	{

		if (
			( scrollx_onoff )
			&&
			( scrolly_onoff )
		)
		{
//n_win_text_set_literal( hwnd, "Scroll : Both" );

			w.state = SIZE_MAXIMIZED;

		} else
		if ( scrollx_onoff )
		{
//n_win_text_set_literal( hwnd, "Scroll : X" );

			if ( ( w.wsy - ( frame_sy * 2 ) - scroll_sy ) > desktop_sy )
			{
//n_win_text_set_literal( hwnd, "Scroll : X : Both" );

				scrolly_onoff = n_posix_true;

				w.state = SIZE_MAXIMIZED;

			}

		} else
		if ( scrolly_onoff )
		{
//n_win_text_set_literal( hwnd, "Scroll : Y" );

			if ( ( w.wsx - nc_sx - scroll_sx ) > desktop_sx )
			{
//n_win_text_set_literal( hwnd, "Scroll : Y : Both" );

				scrollx_onoff = n_posix_true;

				w.state = SIZE_MAXIMIZED;

			}

		}


		// Scroll Position Clipper

		{

			s32 scrmax_x = w.rcsx - w.csx;
			s32 scrmax_y = w.rcsy - w.csy;

			if ( w.scrollx <        0 ) { w.scrollx =        0; }
			if ( w.scrolly <        0 ) { w.scrolly =        0; }
			if ( w.scrollx > scrmax_x ) { w.scrollx = scrmax_x; }
			if ( w.scrolly > scrmax_y ) { w.scrolly = scrmax_y; }

		}

	}


	if ( w_ret != NULL )
	{

		if ( mode & N_WIN_SET_FORCEPOS )
		{
			w.posx = w_ret->posx;
			w.posy = w_ret->posy;
		}

	}

	{

		s32 csx = w.csx;
		s32 csy = w.csy;

		int style_new = style;
		if ( ( scrollx_onoff )&&( scrolly_onoff ) )
		{
			w.csx -= scroll_sx;
			w.csy -= scroll_sy;
		} else {
			if ( scrollx_onoff ) { csy += scroll_sy; style_new |= WS_HSCROLL; }
			if ( scrolly_onoff ) { csx += scroll_sx; style_new |= WS_VSCROLL; }
		}

		RECT rect = { 0, 0, csx, csy };
		AdjustWindowRect( &rect, style_new, n_posix_false );

		w.wsx = rect.right  - rect.left;
		w.wsy = rect.bottom - rect.top;

	}

	if ( mode & N_WIN_SET_INNERPOS )
	{

		if ( scrollx_onoff == n_posix_false )
		{
//n_win_hwndprintf_literal( hwnd, " tx = %d : %d ", desktop_tx, ( w.posx + w.wsx ) );

			if ( ( w.posx + w.wsx ) > desktop_tx )
			{
				w.posx = desktop_tx - w.wsx;// - frame_sx;
			}

			if ( w.posx < desktop_fx )
			{
				w.posx = desktop_fx;
			}

		}

		if ( scrolly_onoff == n_posix_false )
		{
//n_win_hwndprintf_literal( hwnd, " ty = %d : %d ", desktop_ty, ( w.posy + w.wsy ) );

			if ( ( w.posy + w.wsy ) > desktop_ty )
			{
				w.posy = desktop_ty - w.wsy;// - frame_sy;
			}

			if ( w.posy < desktop_fy )
			{
				w.posy = desktop_fy;
			}

		}

	}

	if ( mode & N_WIN_SET_CENTERING )
	{

		if ( scrollx_onoff == n_posix_false )
		{

			w.posx = desktop_fx + ( desktop_sx / 2 ) - ( w.wsx / 2 );

#ifdef _MSC_VER
			// [!] : reason is unknown
			if ( mode & N_WIN_SET_VC_PATCH )
			{
				w.posx -= 1;
			}
#endif // #ifdef _MSC_VER

		}

		if ( scrolly_onoff == n_posix_false )
		{

			w.posy = desktop_fy + ( desktop_sy / 2 ) - ( w.wsy / 2 );

			if ( dwm_onoff )
			{

				if ( WS_SIZEBOX & style )
				{
					w.posy += osy;
				} else {
					w.posy += frame_sy;
				}

			}

#ifdef _MSC_VER
			// [!] : reason is unknown
			if ( mode & N_WIN_SET_VC_PATCH )
			{
				w.posy += 1;
			}
#endif // #ifdef _MSC_VER

		}

	}


	if ( mode & N_WIN_SET_CALCONLY )
	{

		//

	} else {

		UINT swp = SWP_NOACTIVATE | SWP_DRAWFRAME;

		SetWindowPos( hwnd, NULL, w.posx,w.posy, w.wsx,w.wsy, swp );

	}


	if ( w_ret != NULL ) { n_win_alias( &w, w_ret ); }


	return;
}

void
n_win_mbutton2centering_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( n_posix_false == ( WS_CAPTION & n_win_style_get( hwnd ) ) ) { return; }


	switch( msg ) {


	case WM_NCMBUTTONDBLCLK :

		if ( HTCAPTION == LOWORD( wparam ) )
		{

			// [x] : if you don't move a cursor, WM_MBUTTONUP will happen in a client area

			s32 cursor_x, cursor_y; n_win_cursor_position( &cursor_x, &cursor_y );
 
			RECT r; GetWindowRect( hwnd, &r );
			s32 x,y,sx,sy; n_win_rect_expand_size( &r, &x,&y,&sx,&sy );
			s32 desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );

			s32 cursor_rel_x = cursor_x - x;
			s32 cursor_rel_y = cursor_y - y;

			n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CENTERING | N_WIN_SET_VC_PATCH );

			if ( IsZoomed( hwnd ) ) { break; }

			SetCursorPos( w.posx + cursor_rel_x, w.posy + cursor_rel_y );

		}

	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SET

