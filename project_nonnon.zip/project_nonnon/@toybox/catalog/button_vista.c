



#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




void
n_win_cmdlink_gui( HWND hwnd_parent, const n_posix_char *str, UINT style, HWND *hgui )
{

	if ( hgui == NULL ) { return; }


	HWND h = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		str,
		WS_CHILD | WS_VISIBLE | style,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL
	);

	(*hgui) = h;


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char *name_ico = "../../nonnon/project/neko.multi.ico";


	static HWND  hgui[ 40 ];
	static HICON ico;


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Nonnon Button Catalog", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_gui( hwnd, BUTTON, "BS_SPLITBUTTON",         &hgui[ 0] );
		n_win_gui( hwnd, BUTTON, "BS_DEFSPLITBUTTON",      &hgui[ 1] );
		n_win_cmdlink_gui( hwnd, "BS_COMMANDLINK",     14, &hgui[ 2] );
		n_win_cmdlink_gui( hwnd, "BS_DEFCOMMANDLINK",  15, &hgui[ 3] );

		n_win_gui( hwnd, BUTTON, "BS_SPLITBUTTON",         &hgui[ 4] );
		n_win_gui( hwnd, BUTTON, "BS_DEFSPLITBUTTON",      &hgui[ 5] );
		n_win_cmdlink_gui( hwnd, "BS_COMMANDLINK",     14, &hgui[ 6] );
		n_win_cmdlink_gui( hwnd, "BS_DEFCOMMANDLINK",  15, &hgui[ 7] );

		n_win_gui( hwnd, BUTTON, "BS_PUSHBUTTON",          &hgui[ 8] );


		// Style

		n_win_style_add( hgui[ 0], 12 );
		n_win_style_add( hgui[ 1], 13 );

		n_win_style_add( hgui[ 4], 12 );
		n_win_style_add( hgui[ 5], 13 );

		n_win_exedir2curdir();
		ico = n_win_icon_init( name_ico, 0, N_WIN_ICON_INIT_OPTION_DEFAULT );

		n_win_icon_set( hgui[ 4], ico );
		n_win_icon_set( hgui[ 5], ico );
		n_win_icon_set( hgui[ 6], ico );
		n_win_icon_set( hgui[ 7], ico );

		n_win_icon_set( hgui[ 8], ico );


		// Size

		{

		const n_bool redraw = n_true;


		s32 ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );

		ctl *= 2;


		s32 csy = ( ctl * 9 );
		s32 csx = ( ico * 8 );

		n_win_set( hwnd, NULL, csx + m, csy + m, N_WIN_SET_CENTERING );


		n_win_move( hgui[ 0], 0, ctl *  0, csx, ctl, redraw );
		n_win_move( hgui[ 1], 0, ctl *  1, csx, ctl, redraw );
		n_win_move( hgui[ 2], 0, ctl *  2, csx, ctl, redraw );
		n_win_move( hgui[ 3], 0, ctl *  3, csx, ctl, redraw );
		n_win_move( hgui[ 4], 0, ctl *  4, csx, ctl, redraw );
		n_win_move( hgui[ 5], 0, ctl *  5, csx, ctl, redraw );
		n_win_move( hgui[ 6], 0, ctl *  6, csx, ctl, redraw );
		n_win_move( hgui[ 7], 0, ctl *  7, csx, ctl, redraw );
		n_win_move( hgui[ 8], 0, ctl *  8, csx, ctl, redraw );

		}


/*
		{

		DWORD bcm_setfirst = 0x1600;
		DWORD bcm_setnote  = bcm_setfirst + 0x0009;

		n_win_message_send( hgui[ 2], bcm_setnote, 0, L"Test" );
		n_win_message_send( hgui[ 3], bcm_setnote, 0, L"Test" );
		n_win_message_send( hgui[ 6], bcm_setnote, 0, L"Test" );
		n_win_message_send( hgui[ 7], bcm_setnote, 0, L"Test" );

		}
*/


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_icon_exit( ico );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

