// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Requirement
//
//	Visual C++ Express 2008


// Link : dxgi.lib d3d10_1.lib




#include <DXGI.h>
#include <D3D10_1.h>




static IDXGISwapChain         *n_d3d10_IDXGISwapChain         = NULL;
static ID3D10Device1          *n_d3d10_ID3D10Device1          = NULL;
static ID3D10RenderTargetView *n_d3d10_ID3D10RenderTargetView = NULL;




void
n_d3d10_debug( char *str )
{

	MessageBoxA( NULL, str, "", 0 );


	return;
}

void
n_d3d10_render( void )
{

	if ( n_d3d10_ID3D10Device1 != NULL )
	{

		float rgba[ 4 ] = { 0.0f, 0.0f, 1.0f, 1.0f };

		n_d3d10_ID3D10Device1->ClearRenderTargetView
		(
			n_d3d10_ID3D10RenderTargetView,
			rgba
		);

	}

	if ( n_d3d10_IDXGISwapChain != NULL )
	{

		n_d3d10_IDXGISwapChain->Present( 0, 0 );

	}


	return;
}

int
n_d3d10_messageloop()
{

	MSG msg = { 0 };


	while( WM_QUIT != msg.message )
	{

		if( n_win_message_peek( &msg ) )
		{

			TranslateMessage( &msg );
			DispatchMessage( &msg );

		} else {

			n_d3d10_render();

		}

	}


	return (int) msg.wParam;
}

int
n_d3d10_init( HWND hwnd, int sx, int sy )
{

	// [Needed] : call after ShowWindow()


	HRESULT hr;

/*
	IDXGIFactory *n_d3d10IDXGIFactory;
	hr = CreateDXGIFactory(__uuidof(IDXGIFactory), (void**) &n_d3d10IDXGIFactory );
	if ( FAILED( hr ) )
	{
n_d3d10_debug( "CreateDXGIFactory()" );

		return FALSE;
	}


	IDXGIAdapter *n_d3d10_IDXGIAdapter;
	hr = n_d3d10IDXGIFactory->EnumAdapters( 0, &n_d3d10_IDXGIAdapter );
	if ( FAILED( hr ) )
	{
n_d3d10_debug( "EnumAdapters()" );

		return FALSE;
	}
*/


	DXGI_SWAP_CHAIN_DESC sd;
	ZeroMemory( &sd, sizeof(sd) );

	sd.BufferDesc.Width                   = sx;
	sd.BufferDesc.Height                  = sy;
	sd.BufferDesc.RefreshRate.Numerator   = 30;
	sd.BufferDesc.RefreshRate.Denominator = 1;
	sd.BufferDesc.Format                  = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.SampleDesc.Count                   = 1;
	sd.SampleDesc.Quality                 = 0;
	sd.BufferCount                        = 1;
	sd.BufferUsage                        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow                       = hwnd;
	sd.Windowed                           = TRUE;

	hr = D3D10CreateDeviceAndSwapChain1
	(
		NULL,
		//n_d3d10_IDXGIAdapter,
		//D3D10_DRIVER_TYPE_HARDWARE,
		//D3D10_DRIVER_TYPE_SOFTWARE,
		D3D10_DRIVER_TYPE_REFERENCE,
		NULL,
		0,//D3D10_CREATE_DEVICE_SWITCH_TO_REF,//D3D10_CREATE_DEVICE_SINGLETHREADED,
		D3D10_FEATURE_LEVEL_10_1,
		D3D10_1_SDK_VERSION,//D3D10_SDK_VERSION,
		&sd,
		&n_d3d10_IDXGISwapChain,
		&n_d3d10_ID3D10Device1
	);
	if ( FAILED( hr ) )
	{
char str[ 100 ];
wsprintfA( str, "%x @ D3D10CreateDeviceAndSwapChain1()", (int) hr );
n_d3d10_debug( str );

		return FALSE;
	}


	ID3D10Texture2D *n_d3d10_ID3D10Texture2D;
	if (
		FAILED
		(
			n_d3d10_IDXGISwapChain->GetBuffer
			(
				0,
				__uuidof( ID3D10Texture2D ),
				(void**) &n_d3d10_ID3D10Texture2D
			)
		)
	)
	{
		return FALSE;
	}

	hr = n_d3d10_ID3D10Device1->CreateRenderTargetView
	(
		n_d3d10_ID3D10Texture2D,
		NULL,
		&n_d3d10_ID3D10RenderTargetView
	);

	n_d3d10_ID3D10Texture2D->Release();

	if( FAILED( hr ) ) { return FALSE; }


	n_d3d10_ID3D10Device1->OMSetRenderTargets
	(
		1,
		&n_d3d10_ID3D10RenderTargetView,
		NULL
	);


	D3D10_VIEWPORT vp;

	vp.Width    = sx;
	vp.Height   = sy;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;

	n_d3d10_ID3D10Device1->RSSetViewports( 1, &vp );


	return TRUE;
}

void
n_d3d10_free( void )
{

	if ( n_d3d10_ID3D10RenderTargetView != NULL ) { n_d3d10_ID3D10RenderTargetView->Release(); }
	if ( n_d3d10_ID3D10Device1          != NULL ) { n_d3d10_ID3D10Device1->Release(); }
	if ( n_d3d10_IDXGISwapChain         != NULL ) { n_d3d10_IDXGISwapChain->Release(); }


	return;
}
