

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

How to compile

	1 : make an empty project

		don't use DLL project or desktop application project
		a bunch of compile errors will be made

	2 : tweak properties

		ensure Release x86/x64

		you can set "DLL" here
		subsystem Windows is needed

	3 : rebuild it

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

