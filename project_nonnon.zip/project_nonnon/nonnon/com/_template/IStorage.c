// Nonnon COM : IStorage
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_ISTORAGE
#define _H_NONNON_WIN32_COM_ISTORAGE




HRESULT __stdcall
n_IStorage_IUnknown_QueryInterface( IStorage *_this, REFIID iid, void **ppvObject )
{

	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID s = n_com_guid( n_guid_IID_IStorage );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &s ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IStorage_CreateStream( IStorage *_this, const WCHAR *pwcsName, DWORD grfMode, DWORD reserved1, DWORD reserved2, IStream **ppstm )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_OpenStream( IStorage *_this, const WCHAR *pwcsName, void *reserved1, DWORD grfMode, DWORD reserved2, IStream **ppstm )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_CreateStorage( IStorage *_this, const WCHAR *pwcsName, DWORD grfMode, DWORD reserved1, DWORD reserved2, IStorage **ppstg )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_OpenStorage( IStorage *_this, const WCHAR *pwcsName, IStorage *pstgPriority, DWORD grfMode, SNB snbExclude, DWORD reserved, IStorage **ppstg )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_CopyTo( IStorage *_this, DWORD ciidExclude, IID const *rgiidExclude, SNB snbExclude, IStorage *pstgDest )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_MoveElementTo( IStorage *_this, const OLECHAR *pwcsName, IStorage *pstgDest, const OLECHAR *pwcsNewName, DWORD grfFlags )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_Commit( IStorage *_this, DWORD grfCommitFlags )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_Revert( IStorage *_this )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_EnumElements( IStorage *_this, DWORD reserved1, void *reserved2, DWORD reserved3, IEnumSTATSTG **ppenum )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_DestroyElement( IStorage *_this, const OLECHAR *pwcsName )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_RenameElement( IStorage *_this, const WCHAR *pwcsOldName, const WCHAR *pwcsNewName )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_SetElementTimes( IStorage *_this, const WCHAR *pwcsName, FILETIME const *pctime, FILETIME const *patime, FILETIME const *pmtime )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_SetClass( IStorage *_this, REFCLSID clsid )
{

	// [Needed] : S_OK : this is important to make OleCreate() succeed

	// [!] : CLSID_WebBrowser comes here

	//n_com_debug_IUnknown_QueryInterface( NULL, clsid, NULL );


	return S_OK;
}

HRESULT __stdcall
n_IStorage_SetStateBits( IStorage *_this, DWORD grfStateBits, DWORD grfMask )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IStorage_Stat( IStorage *_this, STATSTG *pstatstg, DWORD grfStatFlag )
{
	return E_NOTIMPL;
}




const void *n_IStorage_Vtbl[] = {

	n_IStorage_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IStorage_CreateStream,
	n_IStorage_OpenStream,
	n_IStorage_CreateStorage,
	n_IStorage_OpenStorage,
	n_IStorage_CopyTo,
	n_IStorage_MoveElementTo,
	n_IStorage_Commit,
	n_IStorage_Revert,
	n_IStorage_EnumElements,
	n_IStorage_DestroyElement,
	n_IStorage_RenameElement,
	n_IStorage_SetElementTimes,
	n_IStorage_SetClass,
	n_IStorage_SetStateBits,
	n_IStorage_Stat,

};


IStorage n_IStorage_instance = { (void*) n_IStorage_Vtbl };




#endif // _H_NONNON_WIN32_COM_ISTORAGE

