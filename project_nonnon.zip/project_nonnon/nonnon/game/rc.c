// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GAME_RC
#define _H_NONNON_WIN32_GAME_RC




#include "../neutral/bmp/_codec.c"
#include "../neutral/wav.c"




#define N_GAME_RC_LOAD_BMP 0
#define N_GAME_RC_LOAD_WAV 1
#define N_GAME_RC_LOAD_PNG 2

#define n_game_rc_load_bmp( rc, name ) n_game_rc_load( rc, name, N_GAME_RC_LOAD_BMP )
#define n_game_rc_load_wav( rc, name ) n_game_rc_load( rc, name, N_GAME_RC_LOAD_WAV )
#define n_game_rc_load_png( rc, name ) n_game_rc_load( rc, name, N_GAME_RC_LOAD_PNG )

#define n_game_rc_load_bmp_literal( rc, name ) n_game_rc_load_bmp( rc, n_posix_literal( name ) )
#define n_game_rc_load_wav_literal( rc, name ) n_game_rc_load_wav( rc, n_posix_literal( name ) )
#define n_game_rc_load_png_literal( rc, name ) n_game_rc_load_png( rc, n_posix_literal( name ) )

n_posix_bool
n_game_rc_load
(
	              void *rc,
	const n_posix_char *name,
	               int  type
)
{

	// [!] : section name needs to be "DATA"

	const n_posix_char *sect = n_posix_literal( "DATA" );


	HINSTANCE hinst = GetModuleHandle( NULL );


	HRSRC hrc = FindResource( hinst, name, sect );
	if ( hrc == NULL ) { return n_posix_true; }


	HGLOBAL hglobal = LoadResource( hinst, hrc );
	if ( hglobal == NULL )
	{

		CloseHandle( hrc );

		return n_posix_true;
	}


	u8    *ptr      = LockResource( hglobal );
	DWORD  ptr_byte = SizeofResource( hinst, hrc );


	n_posix_bool ret = n_posix_true;

	if ( rc != NULL )
	{

		if ( type == N_GAME_RC_LOAD_BMP )
		{
			ret = n_bmp_load_onmemory( (n_bmp*) rc, ptr, ptr_byte );
		} else
		if ( type == N_GAME_RC_LOAD_WAV )
		{
			ret = n_wav_load_onmemory( (n_wav*) rc, ptr, ptr_byte );
		} else
		if ( type == N_GAME_RC_LOAD_PNG )
		{
#ifdef _H_NONNON_NEUTRAL_PNG
			ret = n_png_load_onmemory( (n_png*) rc, ptr, ptr_byte );
#endif // #ifdef _H_NONNON_NEUTRAL_PNG
		}

	}


	// [!] : -Wall says "no effect"
	//UnlockResource( hglobal );


	FreeResource( hglobal );


	//CloseHandle( hrc );


	return ret;
}

#ifdef _H_NONNON_NEUTRAL_PNG

#define n_game_rc_load_png2bmp_literal( rc, name ) n_game_rc_load_png2bmp( rc, n_posix_literal( name ) )

n_posix_bool
n_game_rc_load_png2bmp
(
	      n_bmp        *bmp,
	const n_posix_char *name
)
{

	n_png png;
	n_png_zero( &png );

	n_posix_bool ret = n_game_rc_load_png( &png, name );

	if ( ret == n_posix_false ) { ret = n_png_uncompress( &png, bmp ); }

	n_png_free( &png );


	return ret;
}

#endif // #ifdef _H_NONNON_NEUTRAL_PNG


#endif // _H_NONNON_WIN32_GAME_RC

